# PhotoSync

Uploads photos taken or saved on your phone after the app is installed to a Supabase Storage bucket. Photos already on the phone are left alone.

## 1. Supabase setup (once)

In your Supabase project open **SQL Editor** and run:

```sql
-- private bucket for the photos
insert into storage.buckets (id, name, public)
values ('photos', 'photos', false)
on conflict (id) do nothing;

-- let the app upload (it can't read, list or delete anything)
create policy "PhotoSync can upload"
on storage.objects for insert
to anon
with check (bucket_id = 'photos');
```

Then get your **Project URL** and **anon / publishable key** from Project Settings › API.

## 2. Build the APK

Upload the contents of this folder (including the hidden `.github` folder) to a new GitHub repo.
GitHub Actions builds it automatically: Actions tab › latest run › **PhotoSync-apk** artifact.

## 3. On the phone

Install the APK, fill in URL, key, bucket (`photos`) and a folder name, tap
**Save, grant photo access & start**, and choose **Allow all photos**.

Photos land in `photos/<folder>/<yyyy-MM>/<id>_<filename>`.
New photos upload within about a minute. There's also an hourly check as a backup.

## Compression

On by default: photos are shrunk to 2048 px on the longest side as ~82% quality JPEGs
(usually 300–800 KB instead of 3–8 MB). Date, camera and GPS info are kept.
GIFs and photos that are already small are uploaded unchanged.
Uploads pause while the battery is low.

## Viewing

Supabase dashboard › Storage › photos shows thumbnails and lets you download.
