package com.photosync.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Restarts the sync service after the phone reboots. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (Config(ctx).enabled && Perms.hasAnyAccess(ctx)) {
            Sync.start(ctx)
        }
    }
}
