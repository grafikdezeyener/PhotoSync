package com.photosync.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val refresher = object : Runnable {
        override fun run() {
            showStatus()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.start).setOnClickListener {
            requestPermissions(Perms.toRequest(), 1)
        }
        findViewById<Button>(R.id.syncNow).setOnClickListener {
            if (!Perms.hasAnyAccess(this)) {
                requestPermissions(Perms.toRequest(), 1); return@setOnClickListener
            }
            Sync.start(this)
            toast("Syncing…")
        }
        findViewById<Button>(R.id.stop).setOnClickListener {
            Sync.stop(this)
            toast("Stopped")
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (Perms.hasAnyAccess(this)) {
            Sync.start(this)
            toast("Syncing started")
        } else {
            Config(this).status = "Photo access was denied. Tap the button again, or allow it in Settings › Apps › AndroidPhotoSync › Permissions."
        }
        showStatus()
    }

    private fun showStatus() {
        val cfg = Config(this)
        val access = when {
            Perms.hasFullAccess(this) -> "All photos"
            Perms.hasPartialAccess(this) -> "Selected photos only"
            else -> "None"
        }
        val state = if (cfg.enabled) "On" else "Off"
        status.text = "Syncing: $state   •   Photo access: $access\n\n${cfg.status}"
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresher)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refresher)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
