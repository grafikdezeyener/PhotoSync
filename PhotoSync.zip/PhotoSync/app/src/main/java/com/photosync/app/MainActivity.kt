package com.photosync.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var url: EditText
    private lateinit var key: EditText
    private lateinit var bucket: EditText
    private lateinit var folder: EditText
    private lateinit var wifiOnly: CheckBox
    private lateinit var videos: CheckBox
    private lateinit var compress: CheckBox
    private lateinit var maxEdge: EditText
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())

    private val refresher = object : Runnable {
        override fun run() {
            showStatus()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        url = findViewById(R.id.url)
        key = findViewById(R.id.key)
        bucket = findViewById(R.id.bucket)
        folder = findViewById(R.id.folder)
        wifiOnly = findViewById(R.id.wifiOnly)
        videos = findViewById(R.id.videos)
        compress = findViewById(R.id.compress)
        maxEdge = findViewById(R.id.maxEdge)
        status = findViewById(R.id.status)

        val cfg = Config(this)
        url.setText(cfg.url)
        key.setText(cfg.key)
        bucket.setText(cfg.bucket)
        folder.setText(cfg.folder)
        wifiOnly.isChecked = cfg.wifiOnly
        videos.isChecked = cfg.videos
        compress.isChecked = cfg.compress
        maxEdge.setText(cfg.maxEdge.toString())

        findViewById<Button>(R.id.start).setOnClickListener {
            if (!save()) return@setOnClickListener
            requestPermissions(Perms.toRequest(), 1)
        }
        findViewById<Button>(R.id.syncNow).setOnClickListener {
            if (!save()) return@setOnClickListener
            if (!Perms.hasAnyAccess(this)) {
                requestPermissions(Perms.toRequest(), 1); return@setOnClickListener
            }
            Sync.start(this)
            toast("Syncing…")
        }
        findViewById<Button>(R.id.stop).setOnClickListener {
            Sync.stop(this)
            toast("Stopped")
        }
    }

    private fun save(): Boolean {
        val cfg = Config(this)
        cfg.url = url.text.toString()
        cfg.key = key.text.toString()
        cfg.bucket = bucket.text.toString()
        cfg.folder = folder.text.toString()
        cfg.wifiOnly = wifiOnly.isChecked
        cfg.videos = videos.isChecked
        cfg.compress = compress.isChecked
        cfg.maxEdge = maxEdge.text.toString().toIntOrNull() ?: 2048
        if (!cfg.isComplete) {
            toast("Enter the https:// project URL, anon key and bucket")
            return false
        }
        return true
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (Perms.hasAnyAccess(this)) {
            Sync.start(this)
            toast("Syncing started")
        } else {
            Config(this).status = "Photo access was denied. Tap Start again, or allow it in Settings › Apps › PhotoSync › Permissions."
        }
        showStatus()
    }

    private fun showStatus() {
        val cfg = Config(this)
        val access = when {
            Perms.hasFullAccess(this) -> "All photos"
            Perms.hasPartialAccess(this) -> "Selected photos only"
            else -> "None"
        }
        val state = if (cfg.enabled) "On" else "Off"
        status.text = "Syncing: $state   •   Photo access: $access\n\n${cfg.status}"
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresher)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refresher)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
