package com.photosync.app

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class UploadWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    private class Photo(
        val id: Long, val name: String, val mime: String, val takenMs: Long, val isVideo: Boolean
    ) {
        // Image and video tables number separately, so prefix to keep keys unique.
        val key get() = (if (isVideo) "v" else "i") + id
        val baseUri get() =
            if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    }

    private class HttpError(val code: Int, val body: String) : Exception("HTTP $code")

    companion object {
        private val LOCK = Any()
    }

    override fun doWork(): Result = synchronized(LOCK) { sync() }

    private fun sync(): Result {
        val ctx = applicationContext
        val cfg = Config(ctx)
        if (!cfg.enabled) return Result.success()
        if (!cfg.isComplete) {
            cfg.status = "Fill in the Supabase URL, key and bucket"; return Result.success()
        }
        if (!Perms.hasAnyAccess(ctx)) {
            cfg.status = "No photo access — tap Start to grant it"; return Result.success()
        }

        val done = UploadedStore(ctx)
        val pending = queryMedia(cfg).filter { it.key !in done }
        if (pending.isEmpty()) {
            cfg.status = summary(done.size, 0); return Result.success()
        }

        var ok = 0
        var skipped = 0
        for (photo in pending) {
            if (isStopped) return Result.retry()
            cfg.status = "Uploading ${ok + skipped + 1} of ${pending.size}…"
            try {
                upload(cfg, photo)
                done.add(photo.key)
                ok++
            } catch (e: FileNotFoundException) {
                skipped++ // photo was deleted in the meantime
            } catch (e: HttpError) {
                when {
                    e.code == 429 || e.code >= 500 -> {
                        cfg.status = "Supabase busy (${e.code}), will retry. $ok uploaded so far."
                        return Result.retry()
                    }
                    e.code == 413 -> skipped++ // file bigger than Supabase's size limit
                    ok == 0 && skipped == 0 -> {
                        // First upload rejected: almost always a settings/policy problem.
                        cfg.status = "Supabase rejected the upload (${e.code}):\n${e.body.take(300)}"
                        return Result.failure()
                    }
                    else -> skipped++ // just this file (e.g. too large)
                }
            } catch (e: IOException) {
                cfg.status = "Network problem, will retry: ${e.message}. $ok uploaded so far."
                return Result.retry()
            }
        }
        cfg.status = summary(done.size, skipped)
        return Result.success()
    }

    private fun summary(total: Int, skipped: Int): String {
        val time = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(Date())
        val partial = if (Perms.hasPartialAccess(applicationContext))
            "\n\nNote: you allowed only selected items, so new ones won't sync until you allow all photos."
        else ""
        val skip = if (skipped > 0) "\n$skipped item(s) skipped (too large?)." else ""
        return "Up to date — $total item(s) synced since install.\nLast check: $time$skip$partial"
    }

    /** Images (and videos, if enabled) added since install, newest first. */
    private fun queryMedia(cfg: Config): List<Photo> {
        val list = ArrayList<Photo>()
        collect(list, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, false, "image/jpeg", cfg.cutoffSec)
        if (cfg.videos) {
            collect(list, MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, "video/mp4", cfg.cutoffSec)
        }
        return list.sortedByDescending { it.takenMs }
    }

    private fun collect(out: ArrayList<Photo>, base: Uri, isVideo: Boolean, fallbackMime: String, cutoff: Long) {
        // These column names are identical across the Images and Video tables.
        val cols = arrayOf(
            MediaStore.MediaColumns._ID,
            MediaStore.MediaColumns.DISPLAY_NAME,
            MediaStore.MediaColumns.MIME_TYPE,
            MediaStore.MediaColumns.DATE_TAKEN,
            MediaStore.MediaColumns.DATE_ADDED
        )
        applicationContext.contentResolver.query(
            base, cols,
            "${MediaStore.MediaColumns.DATE_ADDED} >= ?",
            arrayOf(cutoff.toString()),
            "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                val taken = c.getLong(3).takeIf { it > 0 } ?: (c.getLong(4) * 1000)
                out += Photo(
                    id = id,
                    name = c.getString(1) ?: "$id",
                    mime = c.getString(2) ?: fallbackMime,
                    takenMs = taken,
                    isVideo = isVideo
                )
            }
        }
    }

    private fun upload(cfg: Config, photo: Photo) {
        val resolver = applicationContext.contentResolver
        var uri = ContentUris.withAppendedId(photo.baseUri, photo.id)
        if (Perms.hasLocation(applicationContext) && !photo.isVideo) {
            // Without this Android strips GPS data from the file.
            try { uri = MediaStore.setRequireOriginal(uri) } catch (e: Exception) {}
        }

        // Compress still photos only (skip GIFs and videos — those upload as-is).
        val small: File? = if (cfg.compress && !photo.isVideo && photo.mime != "image/gif")
            Compressor.compress(applicationContext, uri, cfg.maxEdge)
        else null

        val month = SimpleDateFormat("yyyy-MM", Locale.US).format(Date(photo.takenMs))
        var safeName = photo.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (small != null) safeName = safeName.substringBeforeLast('.') + ".jpg"
        val mime = if (small != null) "image/jpeg" else photo.mime
        val path = listOf(cfg.folder, month, "${photo.id}_$safeName")
            .filter { it.isNotEmpty() }
            .joinToString("/") { Uri.encode(it) }

        val length = if (small != null) small.length() else try {
            resolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: -1L
        } catch (e: SecurityException) {
            -1L
        }

        val conn = URL("${cfg.url}/storage/v1/object/${Uri.encode(cfg.bucket)}/$path")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 30_000
            conn.readTimeout = 120_000
            conn.setRequestProperty("apikey", cfg.key)
            // Legacy anon keys are JWTs ("eyJ..."); new sb_publishable_ keys only go in apikey.
            if (cfg.key.startsWith("eyJ")) conn.setRequestProperty("Authorization", "Bearer ${cfg.key}")
            conn.setRequestProperty("Content-Type", mime)
            conn.setRequestProperty("x-upsert", "false")
            if (length > 0) conn.setFixedLengthStreamingMode(length)
            else conn.setChunkedStreamingMode(64 * 1024)

            val input = small?.inputStream()
                ?: resolver.openInputStream(uri) ?: throw FileNotFoundException()
            input.use { inp -> conn.outputStream.use { out -> inp.copyTo(out, 64 * 1024) } }

            val code = conn.responseCode
            if (code !in 200..299) {
                val body = conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                // Already in the bucket (e.g. app reinstalled) — count as done.
                if (code == 409 || body.contains("Duplicate", ignoreCase = true)) return
                throw HttpError(code, body)
            }
        } finally {
            conn.disconnect()
            small?.delete()
        }
    }
}
