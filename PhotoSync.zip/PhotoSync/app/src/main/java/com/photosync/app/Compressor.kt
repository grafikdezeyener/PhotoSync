package com.photosync.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileNotFoundException
import kotlin.math.max
import kotlin.math.min

/**
 * Shrinks a photo to a JPEG whose long edge is at most [maxEdge] px.
 * Keeps date, camera and GPS info; bakes in the rotation.
 */
object Compressor {

    private val KEEP_TAGS = arrayOf(
        ExifInterface.TAG_DATETIME,
        ExifInterface.TAG_DATETIME_ORIGINAL,
        ExifInterface.TAG_DATETIME_DIGITIZED,
        ExifInterface.TAG_OFFSET_TIME,
        ExifInterface.TAG_OFFSET_TIME_ORIGINAL,
        ExifInterface.TAG_MAKE,
        ExifInterface.TAG_MODEL,
        ExifInterface.TAG_GPS_LATITUDE,
        ExifInterface.TAG_GPS_LATITUDE_REF,
        ExifInterface.TAG_GPS_LONGITUDE,
        ExifInterface.TAG_GPS_LONGITUDE_REF,
        ExifInterface.TAG_GPS_ALTITUDE,
        ExifInterface.TAG_GPS_ALTITUDE_REF,
        ExifInterface.TAG_GPS_DATESTAMP,
        ExifInterface.TAG_GPS_TIMESTAMP
    )

    /** Returns the compressed file, or null if the original should be uploaded instead. */
    fun compress(ctx: Context, uri: Uri, maxEdge: Int, quality: Int = 82): File? {
        val src = File(ctx.cacheDir, "src.tmp")
        val out = File(ctx.cacheDir, "out.jpg")
        try {
            val input = ctx.contentResolver.openInputStream(uri) ?: throw FileNotFoundException()
            input.use { i -> src.outputStream().use { i.copyTo(it, 64 * 1024) } }

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(src.path, bounds)
            val w = bounds.outWidth
            val h = bounds.outHeight
            if (w <= 0 || h <= 0) return null // not decodable, send as-is

            // Decode at roughly the target size so big photos don't use lots of memory.
            var sample = 1
            while (max(w, h) / (sample * 2) >= maxEdge) sample *= 2
            val bmp = BitmapFactory.decodeFile(
                src.path, BitmapFactory.Options().apply { inSampleSize = sample }
            ) ?: return null

            val exif = try { ExifInterface(src.path) } catch (e: Exception) { null }

            val m = Matrix()
            val scale = min(1f, maxEdge.toFloat() / max(bmp.width, bmp.height))
            if (scale < 1f) m.postScale(scale, scale)
            if (exif != null) {
                if (exif.isFlipped) m.postScale(-1f, 1f)
                if (exif.rotationDegrees != 0) m.postRotate(exif.rotationDegrees.toFloat())
            }
            val finalBmp = if (m.isIdentity) bmp
            else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            if (finalBmp !== bmp) bmp.recycle()

            out.outputStream().use { finalBmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
            finalBmp.recycle()

            if (exif != null) {
                try {
                    val dst = ExifInterface(out.path)
                    for (tag in KEEP_TAGS) exif.getAttribute(tag)?.let { dst.setAttribute(tag, it) }
                    dst.setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL.toString())
                    dst.saveAttributes()
                } catch (e: Exception) { /* metadata is nice-to-have */ }
            }

            // Already small (e.g. a screenshot): keep the original.
            if (out.length() >= src.length()) return null
            return out
        } catch (e: OutOfMemoryError) {
            return null
        } finally {
            src.delete()
        }
    }
}
