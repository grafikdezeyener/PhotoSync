package com.photosync.app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import java.io.File

/** Settings saved on the phone. */
class Config(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    /** Only photos added after this moment (seconds) are synced: the app's install time. */
    val cutoffSec: Long
        get() {
            if (!p.contains("cutoffSec")) {
                val installed = ctx.packageManager.getPackageInfo(ctx.packageName, 0).firstInstallTime
                p.edit().putLong("cutoffSec", installed / 1000).apply()
            }
            return p.getLong("cutoffSec", 0)
        }

    var url: String
        get() = p.getString("url", "https://pppeimojnucthtxdokqd.supabase.co")!!
        set(v) = p.edit().putString("url", v.trim().trimEnd('/')).apply()
    var key: String
        get() = p.getString("key", "sb_publishable_BZQ_Ktiib4_BiP5Vls2GtQ_4bM3XYVz")!!
        set(v) = p.edit().putString("key", v.trim()).apply()
    var bucket: String
        get() = p.getString("bucket", "photos")!!
        set(v) = p.edit().putString("bucket", v.trim().trim('/')).apply()
    var folder: String
        get() = p.getString("folder", defaultFolder())!!
        set(v) = p.edit().putString("folder", v.trim().trim('/')).apply()
    var wifiOnly: Boolean
        get() = p.getBoolean("wifiOnly", false)
        set(v) = p.edit().putBoolean("wifiOnly", v).apply()
    var videos: Boolean
        get() = p.getBoolean("videos", true)
        set(v) = p.edit().putBoolean("videos", v).apply()
    var compress: Boolean
        get() = p.getBoolean("compress", true)
        set(v) = p.edit().putBoolean("compress", v).apply()
    var maxEdge: Int
        get() = p.getInt("maxEdge", 2048)
        set(v) = p.edit().putInt("maxEdge", v.coerceIn(320, 8000)).apply()
    var enabled: Boolean
        get() = p.getBoolean("enabled", false)
        set(v) = p.edit().putBoolean("enabled", v).apply()
    var setupDone: Boolean
        get() = p.getBoolean("setupDone", false)
        set(v) = p.edit().putBoolean("setupDone", v).apply()
    var status: String
        get() = p.getString("status", "Not started")!!
        set(v) = p.edit().putString("status", v).apply()

    val isComplete get() = url.startsWith("https://") && key.isNotEmpty() && bucket.isNotEmpty()

    private fun defaultFolder() =
        Build.MODEL.replace(Regex("[^A-Za-z0-9_-]"), "_").ifEmpty { "phone" }
}

/** Remembers which photos (by MediaStore id) are already uploaded. */
class UploadedStore(ctx: Context) {
    private val file = File(ctx.filesDir, "uploaded.txt")
    private val ids: MutableSet<String> =
        if (file.exists()) file.readLines().filter { it.isNotBlank() }.toHashSet()
        else HashSet()

    operator fun contains(key: String) = key in ids
    val size get() = ids.size

    fun add(key: String) {
        if (ids.add(key)) file.appendText("$key\n")
    }

    fun clear() {
        ids.clear(); file.delete()
    }
}

object Perms {
    fun toRequest(): Array<String> = when {
        Build.VERSION.SDK_INT >= 34 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED,
            Manifest.permission.ACCESS_MEDIA_LOCATION
        )
        Build.VERSION.SDK_INT >= 33 -> arrayOf(
            Manifest.permission.READ_MEDIA_IMAGES,
            Manifest.permission.READ_MEDIA_VIDEO,
            Manifest.permission.ACCESS_MEDIA_LOCATION
        )
        Build.VERSION.SDK_INT >= 29 -> arrayOf(
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.ACCESS_MEDIA_LOCATION
        )
        else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    }

    private fun has(ctx: Context, perm: String) =
        ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    /** Full access: every existing and future photo is visible. */
    fun hasFullAccess(ctx: Context) =
        if (Build.VERSION.SDK_INT >= 33)
            has(ctx, Manifest.permission.READ_MEDIA_IMAGES) || has(ctx, Manifest.permission.READ_MEDIA_VIDEO)
        else has(ctx, Manifest.permission.READ_EXTERNAL_STORAGE)

    /** Android 14+ "Select photos" — only the photos the user picked. */
    fun hasPartialAccess(ctx: Context) =
        Build.VERSION.SDK_INT >= 34 && !hasFullAccess(ctx) &&
            has(ctx, Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)

    fun hasAnyAccess(ctx: Context) = hasFullAccess(ctx) || hasPartialAccess(ctx)

    fun hasLocation(ctx: Context) =
        Build.VERSION.SDK_INT >= 29 && has(ctx, Manifest.permission.ACCESS_MEDIA_LOCATION)
}
