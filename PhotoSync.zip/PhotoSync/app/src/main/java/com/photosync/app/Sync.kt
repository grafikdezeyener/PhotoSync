package com.photosync.app

import android.content.Context
import android.provider.MediaStore
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.time.Duration
import java.util.concurrent.TimeUnit

/**
 * Scheduling. Three pieces:
 *  - "upload":   one-off upload run (Sync now, or fired by a new photo)
 *  - "observer": wakes up whenever the phone's photo library changes
 *  - "periodic": hourly safety net, in case the observer misses something
 * WorkManager keeps all of this alive across app closes and reboots.
 */
object Sync {
    private const val UPLOAD = "upload"
    private const val OBSERVER = "observer"
    private const val PERIODIC = "periodic"

    private fun network(ctx: Context) = Constraints.Builder()
        .setRequiredNetworkType(
            if (Config(ctx).wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED
        )
        .setRequiresBatteryNotLow(true) // pause when battery is low
        .build()

    fun start(ctx: Context) {
        Config(ctx).enabled = true
        scheduleObserver(ctx, ExistingWorkPolicy.REPLACE)
        WorkManager.getInstance(ctx).enqueueUniquePeriodicWork(
            PERIODIC,
            ExistingPeriodicWorkPolicy.UPDATE,
            PeriodicWorkRequestBuilder<UploadWorker>(1, TimeUnit.HOURS)
                .setConstraints(network(ctx))
                .build()
        )
        syncNow(ctx)
    }

    fun syncNow(ctx: Context) {
        WorkManager.getInstance(ctx).enqueueUniqueWork(
            UPLOAD,
            ExistingWorkPolicy.APPEND_OR_REPLACE,
            OneTimeWorkRequestBuilder<UploadWorker>()
                .setConstraints(network(ctx))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build()
        )
    }

    fun scheduleObserver(ctx: Context, policy: ExistingWorkPolicy) {
        val trigger = Constraints.Builder()
            .addContentUriTrigger(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, true)
            .addContentUriTrigger(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
            .setTriggerContentUpdateDelay(Duration.ofSeconds(5))
            .setTriggerContentMaxDelay(Duration.ofSeconds(30))
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(
            OBSERVER,
            policy,
            OneTimeWorkRequestBuilder<ObserverWorker>().setConstraints(trigger).build()
        )
    }

    fun stop(ctx: Context) {
        Config(ctx).enabled = false
        val wm = WorkManager.getInstance(ctx)
        listOf(UPLOAD, OBSERVER, PERIODIC).forEach { wm.cancelUniqueWork(it) }
        Config(ctx).status = "Stopped"
    }
}

/** Runs when photos are added/changed: kicks off an upload, then re-arms itself. */
class ObserverWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        if (!Config(applicationContext).enabled) return Result.success()
        Sync.syncNow(applicationContext)
        // Content-URI triggers fire once, so queue the next watcher behind this one.
        Sync.scheduleObserver(applicationContext, ExistingWorkPolicy.APPEND_OR_REPLACE)
        return Result.success()
    }
}
